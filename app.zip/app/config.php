<?php

if ( !defined('SITE_NAME') )
{
    define('SITE_NAME', "ellipsis-TEST");
}

// URL LOCATION 

if ( !defined('BASE_URL') )
{
    define('BASE_URL', "http://159.223.101.2/html/");
}

// DATABASE CONFIGURATION

if ( !defined('HOST_NAME') )
{
    define('HOST_NAME', "http://159.223.101.2:3306");
}

if ( !defined('DB_NAME') )
{
    define('DB_NAME', "urls-elp");
}

if ( !defined('USER_NAME') )
{
    define('USER_NAME', "root");
}

if ( !defined('USER_PASSWORD') )
{
    define('USER_PASSWORD', "Tz@1234!");
}



