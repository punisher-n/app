<?php

include 'config2.php';

$query="select * from link"; // Fetch all the data from the table customers

$result=mysqli_query($link,$query);

?>